<?php get_header(); ?>
	
	You can set an LC powered page to be the front page ( homepage ) in WP admin > Settings > Reading > Front Page Displays.

<?php get_footer(); ?>