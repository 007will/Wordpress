<?php get_header(); ?>
	
	<br><br>
	<div class="align-center">
		You can power this search results with LC by setting the page by in WP admin > Live Composer > Archives &amp; Search
	</div>

<?php get_footer(); ?>

