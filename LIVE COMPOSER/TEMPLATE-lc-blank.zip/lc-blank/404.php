<?php get_header(); ?>

	<div class="align-center">
		<br><br>
		<p><strong>404 - Page Not Found</strong></p>
		The page you are looking for can not be found.
	</div>

<?php get_footer(); ?>