<?php get_header(); ?>
	
	<br><br>
	<div class="align-center">Set a regular page ( WP Admin > Pages ) to be the homepage ( WP Admin > Settings > Reading )</div>

<?php get_footer(); ?>