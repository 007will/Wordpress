	
	<?php echo dslc_hf_get_footer(); ?>

	<?php wp_footer(); ?>

</body>
</html>