<?php
/**
 * The template for displaying search results pages.
 *
 * @link https://livecomposerplugin.com/themes/
 *
 * @package Orao
 */

get_header(); ?>

	You can set an LC powered page to serve as the search results page in WP admin > Live Composer > Archives and Search.

<?php get_footer(); ?>
