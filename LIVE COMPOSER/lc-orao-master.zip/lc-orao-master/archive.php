<?php
/**
 * The template for displaying archive pages.
 *
 * @link https://livecomposerplugin.com/themes/
 *
 * @package Orao
 */

get_header(); ?>

	<div class="align-center">
		You can set an LC powered page to serve as the archive page in WP admin > Live Composer > Archives and Search.
	</div>

<?php get_footer(); ?>
